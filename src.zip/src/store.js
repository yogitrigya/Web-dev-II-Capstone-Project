import { configureStore } from '@reduxjs/toolkit';

import riversSlice from './features/riversSlice';

import projectsSlice from './features/projectsSlice';

export const store = configureStore({

  reducer: {

    rivers: riversSlice,

    projects: projectsSlice,

  },

});