import { Link } from 'react-router-dom';

const Nav = () => {
  return (
    <nav className="bg-primary p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl font-bold text-light">Rivertrack</h1>
        <ul className="flex space-x-6">
          <li><Link to="/" className="text-light hover:text-accent transition-colors font-medium">Home</Link></li>
          <li><Link to="/rivers" className="text-light hover:text-accent transition-colors font-medium">Rivers</Link></li>
          <li><Link to="/projects" className="text-light hover:text-accent transition-colors font-medium">Projects</Link></li>
          <li><Link to="/dashboard" className="text-light hover:text-accent transition-colors font-medium">Dashboard</Link></li>
          <li><Link to="/alerts" className="text-light hover:text-accent transition-colors font-medium">Alerts</Link></li>
        </ul>
      </div>
    </nav>
  );
};

export default Nav;