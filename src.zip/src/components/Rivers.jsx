import { useState } from 'react'

import { useSelector } from 'react-redux'

const Rivers = () => {

  const [search, setSearch] = useState('')

  const [filter, setFilter] = useState('')

  const [sort, setSort] = useState('name')

  const [currentPage, setCurrentPage] = useState(1)

  const itemsPerPage = 5

  const rivers = useSelector(state => state.rivers)

  let filtered = rivers.filter(r => r.name.toLowerCase().includes(search.toLowerCase()))

  if (filter) filtered = filtered.filter(r => r.level === filter)

  filtered.sort((a, b) => {

    if (sort === 'name') return a.name.localeCompare(b.name)

    if (sort === 'level') return a.level.localeCompare(b.level)

    return 0

  })

  const totalPages = Math.ceil(filtered.length / itemsPerPage)

  const paginated = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (

    <div className="p-8 bg-white rounded-lg shadow-md mx-4 mt-8">

      <h1 className="text-4xl font-bold mb-8 text-center text-gray-800">Rivers</h1>

      <div className="mb-6 flex flex-wrap gap-4 justify-center">

        <input

          type="text"

          placeholder="Search by name"

          value={search}

          onChange={(e) => setSearch(e.target.value)}

          className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"

        />

        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">

          <option value="">All Levels</option>

          <option value="Normal">Normal</option>

          <option value="Danger">Danger</option>

          <option value="Low">Low</option>

        </select>

        <select value={sort} onChange={(e) => setSort(e.target.value)} className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">

          <option value="name">Sort by Name</option>

          <option value="level">Sort by Level</option>

        </select>

      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        {paginated.map(river => (

          <div key={river.id} className={`bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border-l-4 ${river.level === 'Danger' ? 'border-red-500 bg-red-50' : river.level === 'Normal' ? 'border-green-500 bg-green-50' : 'border-yellow-500 bg-yellow-50'} hover:scale-105 transition-transform`}>

            <h2 className="text-2xl font-semibold text-gray-800 mb-2">{river.name}</h2>

            <p className={`text-lg font-medium ${river.level === 'Danger' ? 'text-red-600' : river.level === 'Normal' ? 'text-green-600' : 'text-yellow-600'}`}>Level: {river.level}</p>

            <p className="text-gray-600">Location: {river.location}</p>

            <p className="text-gray-600">Water Level: {river.waterLevel} cm</p>

          </div>

        ))}

      </div>

      <div className="mt-8 flex justify-center gap-4">

        <button

          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}

          disabled={currentPage === 1}

          className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"

        >

          Previous

        </button>

        <span className="px-4 py-3 bg-gray-200 text-gray-800 rounded-lg">Page {currentPage} of {totalPages}</span>

        <button

          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}

          disabled={currentPage === totalPages}

          className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"

        >

          Next

        </button>

      </div>

    </div>

  )

}

export default Rivers