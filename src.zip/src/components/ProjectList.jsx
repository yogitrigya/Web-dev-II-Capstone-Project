import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addProject, updateProject, deleteProject } from '../store/slices/projectsSlice';

const ProjectList = ({ projects }) => {
  const dispatch = useDispatch();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: '', budget: '', status: 'Ongoing', delivered: false });

  const handleAdd = () => {
    if (!form.name || !form.budget) return;
    dispatch(addProject({ ...form, id: Date.now(), budget: Number(form.budget) }));
    setForm({ name: '', budget: '', status: 'Ongoing', delivered: false });
  };

  const handleEdit = (project) => {
    setEditing(project.id);
    setForm(project);
  };

  const handleUpdate = () => {
    dispatch(updateProject(form));
    setEditing(null);
    setForm({ name: '', budget: '', status: 'Ongoing', delivered: false });
  };

  const handleDelete = (id) => {
    dispatch(deleteProject(id));
  };

  return (
    <div className="p-6 bg-dark min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-primary mb-6">Government Projects</h2>
        <p className="text-textLight mb-6">
          Manage and track government-funded river restoration projects. Add new initiatives, monitor budgets, 
          update project status, and ensure transparency in project delivery.
        </p>
        <div className="bg-card p-6 rounded-lg shadow-lg mb-6 border border-borderColor">
          <h3 className="text-xl font-semibold text-primary mb-4">{editing ? 'Edit Project' : 'Add New Project'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <input
              type="text"
              value={form.name}
              onChange={e => setForm({...form, name: e.target.value})}
              placeholder="Project Name"
              className="border border-borderColor bg-light text-text p-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
            />
            <input
              type="number"
              value={form.budget}
              onChange={e => setForm({...form, budget: e.target.value})}
              placeholder="Budget (₹)"
              className="border border-borderColor bg-light text-text p-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
            />
          </div>
          <select
            value={form.status}
            onChange={e => setForm({...form, status: e.target.value})}
            className="border border-borderColor bg-light text-text p-3 rounded-2xl mb-4 w-full focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
          >
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
          </select>
          <div className="flex space-x-4">
            <button
              onClick={editing ? handleUpdate : handleAdd}
              className="bg-primary text-light px-6 py-2 rounded-lg hover:bg-secondary transition-colors font-medium"
            >
              {editing ? 'Update' : 'Add'}
            </button>
            {editing && (
              <button
                onClick={() => { setEditing(null); setForm({ name: '', budget: '', status: 'Ongoing', delivered: false }); }}
                className="bg-gray-400 text-light px-6 py-2 rounded-lg hover:bg-gray-500 transition-colors font-medium"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map(p => (
            <div key={p.id} className="bg-card p-4 rounded-3xl shadow-md border border-borderColor hover:shadow-lg transform hover:-translate-y-1 transition-all duration-300 animate-fade-up">
              <h3 className="text-xl font-semibold text-primary mb-2">{p.name}</h3>
              <p className="text-textLight">Budget: <span className="font-semibold text-text">₹{p.budget.toLocaleString()}</span></p>
              <p className="text-textLight">Status: <span className={p.status === 'Completed' ? 'text-green-600 font-bold' : 'text-orange-600 font-bold'}>{p.status}</span></p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button onClick={() => handleEdit(p)} className="bg-primary text-light px-4 py-2 rounded-full hover:bg-secondary transition-colors font-medium text-sm">Edit</button>
                <button onClick={() => handleDelete(p.id)} className="bg-red-500 text-light px-4 py-2 rounded-full hover:bg-red-600 transition-colors font-medium text-sm">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectList;