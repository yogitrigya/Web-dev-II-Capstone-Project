const Footer = () => {
  return (
    <footer className="bg-primary p-6 mt-8 text-light">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left mb-6">
          <div>
            <h4 className="font-bold mb-2">Rivertrack</h4>
            <p className="text-sm">Environmental & Sustainability Monitoring Platform</p>
          </div>
          <div>
            <h4 className="font-bold mb-2">Features</h4>
            <p className="text-sm">River Monitoring • Project Tracking • Data Visualization</p>
          </div>
          <div>
            <h4 className="font-bold mb-2">Contact</h4>
            <p className="text-sm">support@rivertrack.gov.in</p>
          </div>
        </div>
        <hr className="border-secondary mb-4" />
        <div className="text-center text-sm">
          <p>&copy; 2026 Rivertrack. All rights reserved. | Government of India - Environment & Sustainability</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;