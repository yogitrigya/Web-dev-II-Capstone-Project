import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';

const DashboardCharts = ({ rivers, projects }) => {
  // For line chart, assume last value as current level
  const lineData = rivers.map(r => ({ name: r.name, level: r.trend[r.trend.length - 1] }));

  const dangerCount = rivers.filter(r => r.level === 'Danger').length;
  const riskScore = rivers.length ? Math.round((dangerCount / rivers.length) * 100) : 0;
  const topRiskRivers = rivers.filter(r => r.level === 'Danger').map(r => r.name).slice(0, 3);

  const pieData = [
    { name: 'Delivered', value: projects.filter(p => p.delivered).length },
    { name: 'Ongoing', value: projects.filter(p => !p.delivered).length },
  ];

  const COLORS = ['#0066cc', '#0099ff'];

  return (
    <div className="p-6 bg-dark min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-primary mb-2">Dashboard</h2>
        <p className="text-textLight mb-6">
          Comprehensive analysis of water levels and project delivery status. Monitor trends across all monitored rivers 
          and track the progress of government restoration initiatives.
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card p-6 rounded-lg shadow-lg border border-borderColor">
            <h3 className="text-xl font-semibold text-primary mb-4">Water Level Trends</h3>
            <LineChart width={500} height={300} data={lineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
              <XAxis dataKey="name" stroke="#1a1a1a" />
              <YAxis stroke="#1a1a1a" />
              <Tooltip contentStyle={{ backgroundColor: '#ffffff', color: '#1a1a1a', border: '1px solid #e0e0e0' }} />
              <Legend />
              <Line type="monotone" dataKey="level" stroke="#0066cc" strokeWidth={3} />
            </LineChart>
          </div>
          <div className="bg-card p-6 rounded-lg shadow-lg border border-borderColor">
            <h3 className="text-xl font-semibold text-primary mb-4">Project Status Ratio</h3>
            <PieChart width={400} height={300}>
              <Pie
                data={pieData}
                cx={200}
                cy={150}
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#ffffff', color: '#1a1a1a', border: '1px solid #e0e0e0' }} />
            </PieChart>
          </div>
        </div>
        <div className="mt-6 bg-card p-6 rounded-lg shadow-lg border border-borderColor">
          <h3 className="text-xl font-semibold text-primary mb-4">Flood Risk Indicators</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="bg-blue-50 p-5 rounded-3xl border border-blue-100 shadow-sm">
              <p className="text-3xl font-bold text-primary">{dangerCount}</p>
              <p className="text-textLight">Rivers at Danger Level</p>
            </div>
            <div className="bg-blue-50 p-5 rounded-3xl border border-blue-100 shadow-sm">
              <p className="text-3xl font-bold text-secondary">{riskScore}%</p>
              <p className="text-textLight">Flood Risk Score</p>
            </div>
            <div className="bg-blue-50 p-5 rounded-3xl border border-blue-100 shadow-sm">
              <p className="text-lg font-semibold text-primary mb-2">Top Risk Rivers</p>
              <p className="text-textLight">{topRiskRivers.length ? topRiskRivers.join(', ') : 'None'}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
              <p className="text-2xl font-bold text-primary">{rivers.length}</p>
              <p className="text-text">Total Rivers</p>
            </div>
            <div className="text-center bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg">
              <p className="text-2xl font-bold text-primary">{projects.length}</p>
              <p className="text-text">Total Projects</p>
            </div>
            <div className="text-center bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{projects.filter(p => p.delivered).length}</p>
              <p className="text-text">Completed Projects</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardCharts;