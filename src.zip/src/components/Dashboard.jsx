import { useSelector } from 'react-redux'

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts'

const Dashboard = () => {

  const rivers = useSelector(state => state.rivers)

  const projects = useSelector(state => state.projects)

  // Water levels data

  const waterData = rivers.map(r => ({ name: r.name, level: r.waterLevel }))

  // Project status data

  const projectStatus = projects.reduce((acc, p) => {

    acc[p.status] = (acc[p.status] || 0) + 1

    return acc

  }, {})

  const pieData = Object.keys(projectStatus).map(key => ({ name: key, value: projectStatus[key] }))

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']

  return (

    <div style={{ padding: '2rem', backgroundColor: 'white', borderRadius: '0.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', margin: '1rem', marginTop: '2rem' }}>

      <h1 style={{ fontSize: '2.25rem', fontWeight: 'bold', marginBottom: '2rem', textAlign: 'center', color: '#1f2937' }}>Dashboard</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '2rem' }}>

        <div style={{ background: 'linear-gradient(to right, #dbeafe, #bfdbfe)', padding: '1.5rem', borderRadius: '0.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)' }}>

          <h2 style={{ fontSize: '1.5rem', fontWeight: '600', marginBottom: '1rem', color: '#1e40af' }}>Water Levels</h2>

          <BarChart width={400} height={300} data={waterData}>

            <CartesianGrid strokeDasharray="3 3" />

            <XAxis dataKey="name" />

            <YAxis />

            <Tooltip />

            <Legend />

            <Bar dataKey="level" fill="#3b82f6" />

          </BarChart>

        </div>

        <div className="bg-gradient-to-r from-green-100 to-green-200 p-6 rounded-lg shadow-md">

          <h2 className="text-2xl font-semibold mb-4 text-green-800">Project Status</h2>

          <PieChart width={400} height={300}>

            <Pie

              data={pieData}

              cx={200}

              cy={150}

              labelLine={false}

              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}

              outerRadius={80}

              fill="#10b981"

              dataKey="value"

            >

              {pieData.map((entry, index) => (

                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />

              ))}

            </Pie>

            <Tooltip />

          </PieChart>

        </div>

      </div>

    </div>

  )

}

export default Dashboard