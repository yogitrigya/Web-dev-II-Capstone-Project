import { useState } from 'react'

import { useSelector, useDispatch } from 'react-redux'

import { addProject, editProject, deleteProject } from '../features/projectsSlice'

const Projects = () => {

  const [editing, setEditing] = useState(null)

  const [form, setForm] = useState({ name: '', budget: '', status: 'Ongoing' })

  const dispatch = useDispatch()

  const projects = useSelector(state => state.projects)

  const handleAdd = () => {

    if (form.name && form.budget) {

      dispatch(addProject(form))

      setForm({ name: '', budget: '', status: 'Ongoing' })

    }

  }

  const handleEdit = (project) => {

    setEditing(project.id)

    setForm(project)

  }

  const handleSave = () => {

    dispatch(editProject(form))

    setEditing(null)

    setForm({ name: '', budget: '', status: 'Ongoing' })

  }

  const handleDelete = (id) => {

    dispatch(deleteProject(id))

  }

  return (

    <div className="p-8 bg-white rounded-lg shadow-md mx-4 mt-8">

      <h1 className="text-4xl font-bold mb-8 text-center text-gray-800">Government Projects</h1>

      <div className="mb-8 bg-gradient-to-r from-purple-100 to-purple-200 p-6 rounded-lg shadow-md">

        <h2 className="text-2xl font-semibold mb-4 text-purple-800">{editing ? 'Edit Project' : 'Add New Project'}</h2>

        <div className="flex flex-wrap gap-4">

          <input

            type="text"

            placeholder="Project Name"

            value={form.name}

            onChange={(e) => setForm({ ...form, name: e.target.value })}

            className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 flex-1"

          />

          <input

            type="number"

            placeholder="Budget"

            value={form.budget}

            onChange={(e) => setForm({ ...form, budget: e.target.value })}

            className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 flex-1"

          />

          <select

            value={form.status}

            onChange={(e) => setForm({ ...form, status: e.target.value })}

            className="border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"

          >

            <option value="Ongoing">Ongoing</option>

            <option value="Delivered">Delivered</option>

          </select>

          {editing ? (

            <button onClick={handleSave} className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">Save</button>

          ) : (

            <button onClick={handleAdd} className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">Add</button>

          )}

        </div>

      </div>

      <div className="grid gap-6">

        {projects.map(project => (

          <div key={project.id} className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border-l-4 border-indigo-500 hover:scale-105 transition-transform">

            <div className="flex justify-between items-start">

              <div className="flex-1">

                <h3 className="text-2xl font-semibold text-gray-800 mb-2">{project.name}</h3>

                <p className="text-lg text-gray-600">Budget: ₹{project.budget}</p>

                <p className={`text-lg font-medium ${project.status === 'Delivered' ? 'text-green-600' : 'text-orange-600'}`}>Status: {project.status}</p>

              </div>

              <div className="flex gap-2">

                <button onClick={() => handleEdit(project)} className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors">Edit</button>

                <button onClick={() => handleDelete(project.id)} className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">Delete</button>

              </div>

            </div>

          </div>

        ))}

      </div>

    </div>

  )

}

export default Projects