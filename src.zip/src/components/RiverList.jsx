import { useState } from 'react';

const RiverList = ({ rivers }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('');
  const [sort, setSort] = useState('');
  const [page, setPage] = useState(1);
  const itemsPerPage = 10;

  let filtered = rivers.filter(r => r.name.toLowerCase().includes(search.toLowerCase()));
  if (filter) {
    filtered = filtered.filter(r => r.level === filter);
  }
  if (sort) {
    filtered.sort((a, b) => sort === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name));
  }
  const paginated = filtered.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  return (
    <div className="p-6 bg-dark min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-primary mb-6">Rivers Monitoring</h2>
        <div className="bg-card p-6 rounded-lg shadow-lg mb-6 border border-borderColor">
          <p className="text-textLight mb-4">
            Monitor water levels across major Indian rivers. Use the filters below to search by river name, 
            water level status, or sort alphabetically for easier navigation.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by river name"
              className="border border-borderColor bg-light text-text p-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300"
            />
            <select value={filter} onChange={e => setFilter(e.target.value)} className="border border-borderColor bg-light text-text p-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300">
              <option value="">All Levels</option>
              <option value="Normal">Normal</option>
              <option value="Danger">Danger</option>
            </select>
            <select value={sort} onChange={e => setSort(e.target.value)} className="border border-borderColor bg-light text-text p-3 rounded-2xl focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300">
              <option value="">No Sort</option>
              <option value="asc">A-Z</option>
              <option value="desc">Z-A</option>
            </select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {paginated.map(r => (
              <div key={r.id} className="bg-light p-4 rounded-3xl shadow-md border border-borderColor hover:shadow-lg transition-shadow transform hover:-translate-y-1 duration-300 animate-fade-up">
                <h3 className="text-xl font-semibold text-primary mb-2">{r.name}</h3>
                <p className="text-textLight">Level: <span className={r.level === 'Danger' ? 'text-red-600 font-bold' : 'text-green-600 font-bold'}>{r.level}</span></p>
                <p className="text-textLight">Location: {r.location}</p>
                <div className="mt-2">
                  <small className="text-textLight">Trend: {r.trend.join(', ')}</small>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-6 space-x-4">
            <button
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              className="bg-primary text-light px-4 py-2 rounded-lg disabled:opacity-50 hover:bg-secondary transition-colors font-medium"
            >
              Previous
            </button>
            <span className="text-text self-center font-medium">Page {page}</span>
            <button
              onClick={() => setPage(page + 1)}
              disabled={page * itemsPerPage >= filtered.length}
              className="bg-primary text-light px-4 py-2 rounded-lg disabled:opacity-50 hover:bg-secondary transition-colors font-medium"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiverList;