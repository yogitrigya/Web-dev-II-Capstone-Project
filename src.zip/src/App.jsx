import { lazy, Suspense } from 'react'

import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'

const Dashboard = lazy(() => import('./components/Dashboard'))

const Rivers = lazy(() => import('./components/Rivers'))

const Projects = lazy(() => import('./components/Projects'))

function App() {

  return (

    <Router>

      <div style={{

        minHeight: '100vh',

        background: 'linear-gradient(to bottom right, #f0f4ff, #e0e7ff)'

      }}>

        <nav style={{

          background: 'linear-gradient(to right, #2563eb, #9333ea)',

          padding: '1rem',

          color: 'white',

          boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'

        }}>

          <div style={{

            display: 'flex',

            justifyContent: 'space-between',

            alignItems: 'center',

            maxWidth: '1280px',

            margin: '0 auto'

          }}>

            <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>Rivertrack</h1>

            <div style={{ display: 'flex', gap: '1rem' }}>

              <Link to="/" style={{ color: 'white', textDecoration: 'none', cursor: 'pointer' }} onMouseOver={(e) => e.target.style.color = '#fcd34d'} onMouseOut={(e) => e.target.style.color = 'white'}>Dashboard</Link>

              <Link to="/rivers" style={{ color: 'white', textDecoration: 'none', cursor: 'pointer' }} onMouseOver={(e) => e.target.style.color = '#fcd34d'} onMouseOut={(e) => e.target.style.color = 'white'}>Rivers</Link>

              <Link to="/projects" style={{ color: 'white', textDecoration: 'none', cursor: 'pointer' }} onMouseOver={(e) => e.target.style.color = '#fcd34d'} onMouseOut={(e) => e.target.style.color = 'white'}>Projects</Link>

            </div>

          </div>

        </nav>

        <Suspense fallback={<div className="text-center p-8">Loading...</div>}>

          <Routes>

            <Route path="/" element={<Dashboard />} />

            <Route path="/rivers" element={<Rivers />} />

            <Route path="/projects" element={<Projects />} />

          </Routes>

        </Suspense>

      </div>

    </Router>

  )

}

export default App