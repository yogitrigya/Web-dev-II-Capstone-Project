import { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store';
import Nav from './components/Nav';
import Footer from './components/Footer';

const Home = lazy(() => import('./pages/Home'));
const Rivers = lazy(() => import('./pages/Rivers'));
const Projects = lazy(() => import('./pages/Projects'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Alerts = lazy(() => import('./pages/Alerts'));

const App = () => {
  return (
    <Provider store={store}>
      <Router>
        <Nav />
        <Suspense fallback={<div className="flex items-center justify-center min-h-screen bg-dark"><div className="text-center"><div className="text-lg font-semibold text-primary mb-2">Rivertrack</div><div className="text-textLight">Loading...</div></div></div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/rivers" element={<Rivers />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/alerts" element={<Alerts />} />
          </Routes>
        </Suspense>
        <Footer />
      </Router>
    </Provider>
  );
};

export default App;