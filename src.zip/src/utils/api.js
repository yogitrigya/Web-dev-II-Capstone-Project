// Mock data
const mockRivers = [
  { id: 1, name: 'Ganges', level: 'Normal', location: 'Uttar Pradesh', trend: [10, 12, 15, 14, 16] },
  { id: 2, name: 'Yamuna', level: 'Danger', location: 'Delhi', trend: [8, 10, 12, 15, 18] },
  { id: 3, name: 'Brahmaputra', level: 'Normal', location: 'Assam', trend: [5, 7, 9, 8, 10] },
  { id: 4, name: 'Godavari', level: 'Normal', location: 'Maharashtra', trend: [6, 8, 7, 9, 11] },
  { id: 5, name: 'Krishna', level: 'Danger', location: 'Karnataka', trend: [4, 6, 8, 10, 12] },
  // Add more as needed
];

export const fetchRivers = async () => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockRivers), 1000);
  });
};

export const fetchProjects = async () => {
  // Not used since projects are local
  return [];
};