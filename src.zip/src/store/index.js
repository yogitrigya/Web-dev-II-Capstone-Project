import { configureStore } from '@reduxjs/toolkit';
import riversReducer from './slices/riversSlice';
import projectsReducer from './slices/projectsSlice';

export default configureStore({
  reducer: {
    rivers: riversReducer,
    projects: projectsReducer,
  },
});