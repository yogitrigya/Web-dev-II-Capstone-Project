import { createSlice } from '@reduxjs/toolkit';
import { fetchRivers } from '../../utils/api';

const riversSlice = createSlice({
  name: 'rivers',
  initialState: {
    data: [],
    loading: false,
    error: null,
  },
  reducers: {
    setRivers: (state, action) => {
      state.data = action.payload;
      state.loading = false;
    },
    setLoading: (state) => {
      state.loading = true;
    },
    setError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
  },
});

export const { setRivers, setLoading, setError } = riversSlice.actions;

export default riversSlice.reducer;

// Thunk for fetching
export const fetchRiversAsync = () => async (dispatch) => {
  dispatch(setLoading());
  try {
    const data = await fetchRivers();
    dispatch(setRivers(data));
  } catch (error) {
    dispatch(setError(error.message));
  }
};