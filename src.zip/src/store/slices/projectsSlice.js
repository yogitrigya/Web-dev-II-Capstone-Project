import { createSlice } from '@reduxjs/toolkit';

const mockProjects = [
  { id: 1, name: 'Ganges Cleaning Project', budget: 1000000, status: 'Ongoing', delivered: false },
  { id: 2, name: 'Yamuna Restoration', budget: 500000, status: 'Completed', delivered: true },
  { id: 3, name: 'Brahmaputra Flood Control', budget: 2000000, status: 'Ongoing', delivered: false },
];

const projectsSlice = createSlice({
  name: 'projects',
  initialState: {
    data: mockProjects,
    loading: false,
    error: null,
  },
  reducers: {
    addProject: (state, action) => {
      state.data.push(action.payload);
    },
    updateProject: (state, action) => {
      const index = state.data.findIndex(p => p.id === action.payload.id);
      if (index !== -1) {
        state.data[index] = action.payload;
      }
    },
    deleteProject: (state, action) => {
      state.data = state.data.filter(p => p.id !== action.payload);
    },
    setProjects: (state, action) => {
      state.data = action.payload;
    },
  },
});

export const { addProject, updateProject, deleteProject, setProjects } = projectsSlice.actions;

export default projectsSlice.reducer;