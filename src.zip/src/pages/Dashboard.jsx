import { useSelector } from 'react-redux';
import DashboardCharts from '../components/DashboardCharts';

const Dashboard = () => {
  const rivers = useSelector(state => state.rivers.data);
  const projects = useSelector(state => state.projects.data);
  return <DashboardCharts rivers={rivers} projects={projects} />;
};

export default Dashboard;