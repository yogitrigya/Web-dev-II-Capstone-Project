import { useSelector } from 'react-redux';

const Alerts = () => {
  const rivers = useSelector(state => state.rivers.data);
  const dangerRivers = rivers.filter(r => r.level === 'Danger');

  return (
    <div className="p-6 bg-dark min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-primary mb-2">Alerts</h2>
        <p className="text-textLight mb-6">
          Real-time alerts for rivers with water levels at or above danger thresholds. Take immediate action 
          to protect communities and infrastructure in affected areas.
        </p>
        {dangerRivers.length > 0 ? (
          <div className="bg-card p-6 rounded-lg shadow-lg border border-borderColor">
            <h3 className="text-xl font-semibold text-red-600 mb-4">⚠️ Danger Alerts - {dangerRivers.length} Rivers at Risk</h3>
            <ul className="space-y-4">
              {dangerRivers.map(r => (
                <li key={r.id} className="bg-red-50 p-4 rounded-lg border-l-4 border-red-600">
                  <h4 className="text-lg font-semibold text-red-700">{r.name}</h4>
                  <p className="text-textLight">Location: {r.location}</p>
                  <p className="text-textLight">Current Level: <span className="text-red-600 font-bold text-lg">{r.trend[r.trend.length - 1]}</span></p>
                  <p className="text-textLight">Trend: {r.trend.join(' → ')}</p>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="bg-card p-6 rounded-lg shadow-lg text-center border border-borderColor">
            <h3 className="text-xl font-semibold text-green-600 mb-4">✓ No Alerts</h3>
            <p className="text-textLight">All monitored rivers are at normal or safe levels.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Alerts;