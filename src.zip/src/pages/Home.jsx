const Home = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-start bg-dark">
      <div className="w-full bg-gradient-to-r from-primary to-secondary p-12 text-center">
        <h1 className="text-4xl font-bold text-light mb-4">Welcome to Rivertrack</h1>
        <p className="text-lg text-light">Monitoring Indian Rivers and Government Restoration Projects</p>
      </div>

      <div className="max-w-6xl mx-auto p-8">
        <div className="bg-card rounded-3xl shadow-xl p-8 mb-6 border border-borderColor animate-fade-up">
          <h2 className="text-2xl font-bold text-primary mb-4">Overview</h2>
          <p className="text-textLight mb-4 leading-relaxed">
            Rivertrack is a comprehensive web application designed to monitor water levels across major Indian rivers 
            and track the progress of government-funded river restoration projects. Our platform combines real-time data 
            analysis with intuitive visualization tools to help environmental authorities, policymakers, and stakeholders 
            make informed decisions about river management and sustainability.
          </p>
          <p className="text-textLight mb-4 leading-relaxed">
            With growing concerns about water scarcity and environmental degradation, effective river monitoring has become 
            essential. Rivertrack provides a centralized platform for tracking water level trends, identifying danger zones, 
            and monitoring the delivery status of critical restoration initiatives across the nation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-card rounded-3xl shadow-md p-6 border border-borderColor hover:shadow-xl transition-all duration-300 animate-fade-up">
            <h3 className="text-xl font-semibold text-primary mb-3">River Monitoring</h3>
            <p className="text-textLight">
              Access comprehensive water level data for major Indian rivers with advanced filtering, searching, and pagination. 
              Track trends and identify potential risks in real-time.
            </p>
          </div>
          <div className="bg-card rounded-3xl shadow-md p-6 border border-borderColor hover:shadow-xl transition-all duration-300 animate-fade-up delay-100">
            <h3 className="text-xl font-semibold text-secondary mb-3">Project Tracking</h3>
            <p className="text-textLight">
              Manage government river restoration projects with complete CRUD functionality. Monitor budgets, track delivery 
              status, and ensure project transparency across all stakeholders.
            </p>
          </div>
          <div className="bg-card rounded-3xl shadow-md p-6 border border-borderColor hover:shadow-xl transition-all duration-300 animate-fade-up delay-200">
            <h3 className="text-xl font-semibold text-accent mb-3">Data Visualization</h3>
            <p className="text-textLight">
              Explore interactive charts and dashboards showcasing water level trends, project completion ratios, and 
              comprehensive statistics for informed decision-making.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-card rounded-3xl shadow-lg overflow-hidden border border-borderColor animate-fade-up">
            <img
              src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
              alt="Flood water in a city"
              className="w-full h-72 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-primary mb-3">What are floods?</h3>
              <p className="text-textLight leading-relaxed">
                Floods occur when water overflows from rivers, lakes, or coastal areas and inundates nearby land.
                Heavy rainfall, snowmelt, storm surges, and blocked drainage systems can all contribute to flood events.
                These natural disasters often damage infrastructure, displace communities, and strain emergency response systems.
              </p>
            </div>
          </div>
          <div className="bg-card rounded-3xl shadow-lg overflow-hidden border border-borderColor animate-fade-up delay-100">
            <img
              src="https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=1200&q=80"
              alt="Flooded streets"
              className="w-full h-72 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-primary mb-3">Flood History in India</h3>
              <p className="text-textLight leading-relaxed mb-3">
                India has experienced significant flood events for decades, including the 1978 Bihar floods, the 2013 Uttarakhand flash floods, 
                the 2018 Kerala floods, and recurring inundations across Assam and Bihar. Each event highlights the urgent need for improved 
                river management and sustainable restoration projects.
              </p>
              <p className="text-textLight leading-relaxed">
                Rivertrack helps record these trends and encourages data-driven planning, so communities can better prepare for future flood risks.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-3xl shadow-lg p-8 border border-borderColor">
          <h2 className="text-2xl font-bold text-primary mb-4">Key Features</h2>
          <ul className="space-y-3">
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Real-time Alerts:</strong> Get notified when water levels reach danger thresholds
            </li>
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Advanced Search & Filtering:</strong> Find rivers by name, location, or water level status
            </li>
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Pagination:</strong> Browse through large datasets efficiently
            </li>
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Project Management:</strong> Add, edit, and delete restoration projects with budget tracking
            </li>
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Interactive Dashboards:</strong> Visualize trends and statistics with professional charts
            </li>
            <li className="flex items-center text-textLight">
              <span className="w-2 h-2 bg-secondary rounded-full mr-3"></span>
              <strong>Performance Optimized:</strong> Fast loading with lazy-loaded routes and efficient state management
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Home;