import { useSelector } from 'react-redux';
import ProjectList from '../components/ProjectList';

const Projects = () => {
  const { data } = useSelector(state => state.projects);
  return <ProjectList projects={data} />;
};

export default Projects;