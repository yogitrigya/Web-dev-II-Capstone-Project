import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRiversAsync } from '../store/slices/riversSlice';
import RiverList from '../components/RiverList';

const Rivers = () => {
  const dispatch = useDispatch();
  const { data, loading, error } = useSelector(state => state.rivers);

  useEffect(() => {
    dispatch(fetchRiversAsync());
  }, [dispatch]);

  if (loading) return <div className="flex items-center justify-center min-h-screen bg-dark text-primary"><div className="text-lg font-semibold">Loading river data...</div></div>;
  if (error) return <div className="flex items-center justify-center min-h-screen bg-dark text-red-600"><div className="text-lg font-semibold">Error: {error}</div></div>;

  return <RiverList rivers={data} />;
};

export default Rivers;