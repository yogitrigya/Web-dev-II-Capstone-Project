import { createSlice } from '@reduxjs/toolkit';

const initialRivers = [

  { id: 1, name: 'Ganges', level: 'Normal', location: 'Uttar Pradesh', waterLevel: 150 },

  { id: 2, name: 'Yamuna', level: 'Danger', location: 'Delhi', waterLevel: 200 },

  { id: 3, name: 'Brahmaputra', level: 'Normal', location: 'Assam', waterLevel: 140 },

  { id: 4, name: 'Godavari', level: 'Low', location: 'Andhra Pradesh', waterLevel: 100 },

  { id: 5, name: 'Krishna', level: 'Normal', location: 'Karnataka', waterLevel: 160 },

  { id: 6, name: 'Narmada', level: 'Danger', location: 'Madhya Pradesh', waterLevel: 180 },

  { id: 7, name: 'Indus', level: 'Normal', location: 'Punjab', waterLevel: 130 },

  { id: 8, name: 'Mahanadi', level: 'Low', location: 'Odisha', waterLevel: 90 },

  { id: 9, name: 'Kaveri', level: 'Normal', location: 'Tamil Nadu', waterLevel: 170 },

  { id: 10, name: 'Tapti', level: 'Danger', location: 'Gujarat', waterLevel: 190 },

];

const riversSlice = createSlice({

  name: 'rivers',

  initialState: initialRivers,

  reducers: {

    // Add reducers if needed for updates

  },

});

export default riversSlice.reducer;