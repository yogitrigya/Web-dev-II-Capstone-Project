import { createSlice } from '@reduxjs/toolkit';

const initialProjects = [

  { id: 1, name: 'Ganges Restoration Project', budget: 1000000, status: 'Ongoing', delivered: false },

  { id: 2, name: 'Yamuna Cleaning Initiative', budget: 500000, status: 'Delivered', delivered: true },

  { id: 3, name: 'Brahmaputra Flood Control', budget: 800000, status: 'Ongoing', delivered: false },

  { id: 4, name: 'Godavari River Development', budget: 600000, status: 'Delivered', delivered: true },

  { id: 5, name: 'Krishna Water Management', budget: 700000, status: 'Ongoing', delivered: false },

];

const projectsSlice = createSlice({

  name: 'projects',

  initialState: initialProjects,

  reducers: {

    addProject: (state, action) => {

      state.push({ ...action.payload, id: Date.now() });

    },

    editProject: (state, action) => {

      const index = state.findIndex(p => p.id === action.payload.id);

      if (index !== -1) state[index] = action.payload;

    },

    deleteProject: (state, action) => {

      return state.filter(p => p.id !== action.payload);

    },

  },

});

export const { addProject, editProject, deleteProject } = projectsSlice.actions;

export default projectsSlice.reducer;