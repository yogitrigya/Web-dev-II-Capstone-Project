- [x] Verify that the copilot-instructions.md file in the .github directory is created.

- [x] Clarify Project Requirements
	Project requirements already specified in user query.

- [x] Scaffold the Project
	Project structure created manually for Vite React JS.

- [x] Customize the Project
	Implemented Redux Toolkit for state management, React Router with lazy loading, Tailwind CSS for styling, mock data in slices, CRUD operations for projects, pagination/search/filter/sort for rivers, dashboard with charts using Recharts.

- [x] Install Required Extensions
	No extensions needed.

- [x] Compile the Project
	Dependencies installed, linting passed without errors.

- [x] Create and Run Task
	No custom tasks needed for Vite project.

- [x] Launch the Project
	Verify that all previous steps have been completed.
	Prompt user for debug mode, launch only if confirmed.

- [x] Ensure Documentation is Complete
	Verify that README.md and the copilot-instructions.md file in the .github directory exists and contains current project information.
	Clean up the copilot-instructions.md file in the .github directory by removing all HTML comments.

- Work through each checklist item systematically.
- Keep communication concise and focused.
- Follow development best practices.